using System;

namespace Proxy
{
    abstract class Subject
    {
        public abstract void Request();
    }
}
