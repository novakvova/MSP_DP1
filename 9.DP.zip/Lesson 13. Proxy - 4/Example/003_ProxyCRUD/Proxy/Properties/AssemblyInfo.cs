﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("Proxy")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CBS")]
[assembly: AssemblyProduct("Proxy")]
[assembly: AssemblyCopyright("Copyright © CBS 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("3c415612-9c52-4782-14a0-21fe2937af34")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
