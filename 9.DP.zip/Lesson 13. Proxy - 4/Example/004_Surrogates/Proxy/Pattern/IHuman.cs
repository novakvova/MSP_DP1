using System;

namespace Proxy
{
    interface IHuman
    {
        void Request();
    }
}
