﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoolInternString
{
    class Program
    {
        static void Main(string[] args)
        {
            //Здесь используется паттерн flywieght
            //Пул интранирования строк - это таблица
            string a = "hello";
            string b = "hello";
            //набрать сw и нажать два раза Tab
            Console.WriteLine(ReferenceEquals(a,b)); 

        }
    }
}
