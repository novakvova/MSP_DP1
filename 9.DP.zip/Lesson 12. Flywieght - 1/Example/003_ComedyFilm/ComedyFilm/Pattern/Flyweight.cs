﻿using System;

namespace ComedyFilm
{
    abstract class Flyweight
    {
        public abstract void Greeting(string speech);
    }
}
