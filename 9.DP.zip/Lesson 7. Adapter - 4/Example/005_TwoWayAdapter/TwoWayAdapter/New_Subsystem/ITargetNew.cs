﻿
namespace TwoWayAdapter
{
    interface ITargetNew
    {
        void MethodNew();
    }
}
