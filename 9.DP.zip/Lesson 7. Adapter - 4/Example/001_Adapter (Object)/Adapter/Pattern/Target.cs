using System;

namespace Adapter
{
    abstract class Target
    {
        public abstract void Request();
    }
}
