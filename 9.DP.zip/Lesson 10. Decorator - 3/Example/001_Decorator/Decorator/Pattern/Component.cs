﻿using System;

namespace Decorator
{
    abstract class Component
    {
        public abstract void Operation();
    }
}
