﻿
namespace FactoryMethod
{
    public enum Action
    {
        NewDoc,
        OpenDoc
    }
}
