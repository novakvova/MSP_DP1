﻿using System;


namespace ServiceLocator_1
{
    interface IServiceB
    {

    }
}
