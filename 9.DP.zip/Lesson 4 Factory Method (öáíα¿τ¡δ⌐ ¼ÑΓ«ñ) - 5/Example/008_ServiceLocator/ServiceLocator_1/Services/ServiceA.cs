﻿using System;


namespace ServiceLocator_1
{
    class ServiceA : IServiceA
    {

    }
}
