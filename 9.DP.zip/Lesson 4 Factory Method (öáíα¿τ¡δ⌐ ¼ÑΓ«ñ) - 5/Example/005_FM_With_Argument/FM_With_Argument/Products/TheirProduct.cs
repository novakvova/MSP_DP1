﻿
namespace FM_With_Argument
{
    class TheirProduct : Product
    {
    }
}
