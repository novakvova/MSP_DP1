﻿
namespace FM_With_Argument
{
    class MyProduct : Product
    {
    }
}
