﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPrototype
{
    //Этот клас описывает точку
    public class PointDescription
    {
        //Открытие для просмотра
        public string petName;
        public Guid PointID;
        public PointDescription()
        {
            this.petName = "No name";
            PointID = Guid.NewGuid(); //Глобальный уникальный идентифыкаторр - это статичтически уникальное 128-разрядное значение
        }
    }
}
