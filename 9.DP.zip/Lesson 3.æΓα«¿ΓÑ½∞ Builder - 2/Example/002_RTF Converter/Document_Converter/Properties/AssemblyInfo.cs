﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Document_Converter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Document_Converter")]
[assembly: AssemblyCopyright("Copyright © CyberBionic Systematics 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("d6c4eadf-f76c-4cc5-83bb-efa392b305de")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
