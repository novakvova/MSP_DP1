using System;

namespace Facade
{
    class SubSystemA
    {
        public void OperationA()
        {
            Console.WriteLine("SubSystem A");
        }
    }
}
