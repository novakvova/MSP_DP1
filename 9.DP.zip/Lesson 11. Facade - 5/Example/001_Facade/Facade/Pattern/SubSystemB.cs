using System;

namespace Facade
{
    class SubSystemB
    {
        public void OperationB()
        {
            Console.WriteLine("SubSystem B");
        }
    }
}
