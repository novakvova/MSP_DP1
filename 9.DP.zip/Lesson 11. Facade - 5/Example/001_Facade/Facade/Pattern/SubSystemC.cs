using System;

namespace Facade
{
    class SubSystemC
    {
        public void OperationC()
        {
            Console.WriteLine("SubSystem C");
        }
    }
}
