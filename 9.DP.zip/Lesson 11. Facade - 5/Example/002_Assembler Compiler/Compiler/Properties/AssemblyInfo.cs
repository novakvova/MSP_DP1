﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CompilationSystem")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CyberBionic Systematics")]
[assembly: AssemblyProduct("CompilationSystem")]
[assembly: AssemblyCopyright("Copyright © CyberBionic Systematics  2013")]
[assembly: AssemblyTrademark("CyberBionic Systematics")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("fcc20864-937b-413f-87bd-ea5c6beb2dd0")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
