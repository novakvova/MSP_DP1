﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Facade")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CyberBionic Systematics")]
[assembly: AssemblyProduct("Facade")]
[assembly: AssemblyCopyright("Copyright © CyberBionic Systematics 2013")]
[assembly: AssemblyTrademark("CyberBionic Systematics")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("57217618-a973-4618-8891-4914e294e2b4")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
