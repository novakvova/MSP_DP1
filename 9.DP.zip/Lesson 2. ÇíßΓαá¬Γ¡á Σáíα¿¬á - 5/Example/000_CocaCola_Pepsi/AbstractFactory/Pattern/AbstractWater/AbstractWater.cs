using System;

namespace AbstractFactory
{
    abstract class AbstractWater
    {
    }
}
