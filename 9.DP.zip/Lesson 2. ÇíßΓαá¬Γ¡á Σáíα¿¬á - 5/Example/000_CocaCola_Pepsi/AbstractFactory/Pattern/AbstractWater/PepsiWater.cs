using System;

namespace AbstractFactory
{
    class PepsiWater : AbstractWater
    {
    }
}
