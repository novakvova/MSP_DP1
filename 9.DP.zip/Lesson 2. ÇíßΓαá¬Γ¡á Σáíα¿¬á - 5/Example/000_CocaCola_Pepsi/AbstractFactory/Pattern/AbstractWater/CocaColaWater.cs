using System;

namespace AbstractFactory
{
    class CocaColaWater : AbstractWater
    {
    }
}
