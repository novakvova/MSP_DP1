using System;

namespace AbstractFactory
{
    abstract class AbstractBottle
    {
        public abstract void Interact(AbstractWater water);
    }
}
