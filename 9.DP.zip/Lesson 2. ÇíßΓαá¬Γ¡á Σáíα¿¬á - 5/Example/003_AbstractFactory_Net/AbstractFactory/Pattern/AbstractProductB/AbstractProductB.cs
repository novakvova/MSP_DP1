using System;

namespace AbstractFactory
{
    interface IAbstractProductB
    {
        void Interact(IAbstractProductA a);
    }
}
