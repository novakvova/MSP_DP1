﻿using System;

namespace AbstractFactory
{
    enum Product
    {
        ProductA,
        ProductB
    }
}
