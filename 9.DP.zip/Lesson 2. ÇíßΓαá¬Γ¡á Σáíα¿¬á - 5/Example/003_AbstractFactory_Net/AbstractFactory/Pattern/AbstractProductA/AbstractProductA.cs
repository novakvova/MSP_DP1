using System;

namespace AbstractFactory
{
    interface IAbstractProductA
    {
    }
}
