using System;

namespace AbstractFactory
{
    class ProductA1 : IAbstractProductA
    {
    }
}
