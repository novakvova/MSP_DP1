﻿using System;

namespace AbstractFactory
{
    enum Factory
    {
        ConcreteFactory1,
        ConcreteFactory2
    }
}
