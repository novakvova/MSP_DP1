using System;

namespace AbstractFactory
{
    abstract class AbstractProductB
    {
        public abstract void Interact(AbstractProductA a);
    }
}
