using System;

namespace AbstractFactory
{
    abstract class AbstractProductA
    {
    }
}
