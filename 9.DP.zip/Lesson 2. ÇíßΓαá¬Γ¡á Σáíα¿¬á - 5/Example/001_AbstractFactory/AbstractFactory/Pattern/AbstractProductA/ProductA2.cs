using System;

namespace AbstractFactory
{
    class ProductA2 : AbstractProductA
    {
    }
}
