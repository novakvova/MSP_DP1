using System;

namespace AbstractFactory
{
    class Program
    {
        public static void Main()
        {
            Client client = null;

        }
    }    
}
